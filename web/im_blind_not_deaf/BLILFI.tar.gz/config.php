<?php
$conn = mysqli_connect('localhost','root','!1@2#3$4qwerasdf','tdf');
if (!$conn){
	echo "connection fali";
}

$nice_tendollar="Congraturation!!!!"."<br>"."Next Question: LFI(Local File Inclusion) in "."phpMyAdmin 4.8.0~4.8.1..."."<br>"." URL:phpmyadmin/index.php.........   flag.txt"."<br>"."root's password:!1@2#3$4qwerasdf"."<br>";
?>

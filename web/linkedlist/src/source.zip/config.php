<?php
$flag1 = "*** censored ***";
$flag2 = "*** censored ***";
?>
